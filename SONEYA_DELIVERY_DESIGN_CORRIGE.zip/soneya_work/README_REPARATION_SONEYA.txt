SONEYA DELIVERY — VERSION CORRIGÉE (BASE DESIGN)

Corrections intégrées :
- AppInner récupère maintenant `space` via useApp(), ce qui corrige les trois erreurs TS2304 dans src/App.tsx.
- La dépendance esbuild est déclarée en version ^0.28.2 pour satisfaire le peer dependency optionnel de Vite 8.
- Le système visuel responsive a été harmonisé dans src/index.css, avec des accents distincts pour Client, Livreur, Partenaire et Administration.
- Les largeurs des espaces métier sont adaptées à leur usage, notamment l'administration et le tableau partenaire.

Installation sous Windows (PowerShell ou CMD), depuis le dossier du projet :
  npm install
  npm run lint
  npm run build
  npm run dev

Important : l'environnement de préparation ne disposait pas d'accès au registre npm (DNS indisponible). L'installation complète et le build n'ont donc pas pu être exécutés ici. Le code a été modifié et inspecté, mais il faut confirmer le résultat de `npm install`, `npm run lint` et `npm run build` sur ton PC.

Les paiements, SMS/OTP, stockage et statistiques du projet restent en mode simulation/local tant qu'un vrai backend n'est pas connecté. Cette archive ne configure pas Supabase.
