import React from 'react';
import {
  ArrowUpRight, ShoppingBag, ShieldCheck, MapPin, Search, Activity
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

type SpaceCardProps = {
  number: string;
  title: string;
  subtitle: string;
  description: string;
  path: string;
  accent: string;
  onEnter: () => void;
  children: React.ReactNode;
};

const SpaceCard: React.FC<SpaceCardProps> = ({
  number, title, subtitle, description, accent, onEnter, children
}) => (
  <article className="portal-card group">
    <div className="portal-preview" data-accent={accent}>
      {children}
      <div className="portal-preview-shade" />
      <span className="portal-preview-tag">SONEYA / {number}</span>
      <button className="portal-preview-open" onClick={onEnter} aria-label={`Ouvrir ${title}`}>
        <ArrowUpRight size={18} />
      </button>
    </div>
    <div className="portal-card-copy">
      <div>
        <p className="portal-eyebrow">{subtitle}</p>
        <h2>{title}</h2>
        <p className="portal-description">{description}</p>
      </div>
      <button className="portal-enter" onClick={onEnter}>
        Accéder à l’espace <ArrowUpRight size={16} />
      </button>
    </div>
  </article>
);

export const LandingPortal: React.FC = () => {
  const { setSpace, setShowLandingPortal, setIsAuthModalOpen } = useApp();

  const enter = (space: 'client' | 'partner' | 'courier' | 'admin') => {
    const paths = { client: '/client', courier: '/livreur', partner: '/partenaire', admin: '/admin' };
    window.history.pushState({}, '', paths[space]);
    setSpace(space);
    setShowLandingPortal(false);
  };

  return (
    <div className="portal-page">
      <header className="portal-header">
        <a className="portal-brand" href="/" onClick={(e) => { e.preventDefault(); window.history.pushState({}, '', '/'); setShowLandingPortal(true); }}>
          <span className="portal-brand-mark">S</span>
          <span><strong>SONEYA</strong><small>DELIVERY · GUINÉE</small></span>
        </a>
        <div className="portal-header-actions">
          <span className="portal-location"><MapPin size={14} /> CONAKRY, GUINÉE</span>
          <button className="portal-login" onClick={() => setIsAuthModalOpen(true)}>Connexion</button>
        </div>
      </header>

      <main className="portal-main">
        <section className="portal-intro">
          <div className="portal-kicker"><span /> PLATEFORME DE LIVRAISON · GUINÉE</div>
          <h1>Une plateforme.<br /><em>Quatre espaces.</em></h1>
          <p>Une expérience dédiée à chaque acteur de la livraison. Choisissez votre espace pour continuer.</p>
        </section>

        <section className="portal-grid" aria-label="Les quatre espaces Soneya">
          <SpaceCard number="01" title="Soneya Client" subtitle="Commander & suivre" description="Explorez les commerces, composez votre panier et suivez vos commandes." path="/client" accent="green" onEnter={() => enter('client')}>
            <div className="preview-client">
              <div className="preview-phone">
                <div className="preview-phone-top"><span>09:41</span><span>● ● ▰</span></div>
                <div className="preview-search"><Search size={9}/> Rechercher un plat, un commerce</div>
                <div className="preview-categories"><i>Tout</i><i>Repas</i><i>Courses</i><i>Pharmacie</i></div>
                <div className="preview-food"><div className="food-art">✦</div><div><b>Le Comptoir</b><small>Repas · 20–30 min</small><strong>4.8 ★</strong></div></div>
                <div className="preview-food"><div className="food-art food-art-2">✦</div><div><b>Maison Fanta</b><small>Grillades · 25 min</small><strong>4.9 ★</strong></div></div>
              </div>
              <div className="preview-float"><ShoppingBag size={13}/><span>Panier prêt</span><b>2 articles</b></div>
            </div>
          </SpaceCard>

          <SpaceCard number="02" title="Soneya Rider" subtitle="Gérer les livraisons" description="Recevez vos missions, organisez vos trajets et consultez vos revenus." path="/livreur" accent="blue" onEnter={() => enter('courier')}>
            <div className="preview-rider">
              <div className="rider-map">
                <div className="map-roads" />
                <span className="map-pin pin-a"><MapPin size={15}/></span><span className="map-pin pin-b"><MapPin size={15}/></span><span className="map-pin pin-c"><MapPin size={15}/></span>
                <div className="map-route" />
                <div className="map-label">KIPÉ · KALOUM</div>
              </div>
              <div className="rider-stats"><div><small>Courses aujourd’hui</small><b>08</b></div><div><small>Revenus estimés</small><b>185 000 <i>GNF</i></b></div></div>
              <div className="rider-status"><span/> Disponible pour une mission</div>
            </div>
          </SpaceCard>

          <SpaceCard number="03" title="Soneya Business" subtitle="Piloter son commerce" description="Centralisez les commandes, gérez votre catalogue et suivez votre activité." path="/partenaire" accent="lime" onEnter={() => enter('partner')}>
            <div className="preview-business">
              <div className="business-top"><span>Vue d’ensemble</span><span>•••</span></div>
              <div className="business-metrics"><div><small>Commandes</small><b>24</b><em>+12%</em></div><div><small>Ventes du jour</small><b>2,8M</b><em>GNF</em></div></div>
              <div className="business-orders">
                <div className="order-line"><span className="order-dot dot-green"/><span><b>#SN-2048</b><small>2 articles · Kipé</small></span><strong>En cours</strong></div>
                <div className="order-line"><span className="order-dot dot-orange"/><span><b>#SN-2047</b><small>3 articles · Lambanyi</small></span><strong>À préparer</strong></div>
                <div className="order-line"><span className="order-dot dot-gray"/><span><b>#SN-2046</b><small>1 article · Kaloum</small></span><strong>Terminée</strong></div>
              </div>
            </div>
          </SpaceCard>

          <SpaceCard number="04" title="Soneya Admin" subtitle="Superviser l’ensemble" description="Pilotez les opérations, les comptes, les partenaires et les indicateurs." path="/admin" accent="dark" onEnter={() => enter('admin')}>
            <div className="preview-admin">
              <div className="admin-top"><span>SONEYA CONTROL</span><Activity size={12}/></div>
              <div className="admin-map"><div className="admin-grid-lines"/><span className="admin-node n1"/><span className="admin-node n2"/><span className="admin-node n3"/><span className="admin-node n4"/><span className="admin-node n5"/></div>
              <div className="admin-kpis"><div><small>Commandes</small><b>1 284</b></div><div><small>Partenaires</small><b>86</b></div><div><small>Livreurs actifs</small><b>42</b></div></div>
              <div className="admin-chart"><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/></div>
            </div>
          </SpaceCard>
        </section>

        <section className="portal-footnote">
          <div className="portal-footnote-icon"><ShieldCheck size={18}/></div>
          <div><strong>Un accès adapté à chaque profil</strong><p>Les quatre espaces partagent la même plateforme, avec des parcours et des outils distincts selon le rôle.</p></div>
          <span className="portal-powered">UNE SOLUTION GHT</span>
        </section>
      </main>

      <footer className="portal-footer"><span>© {new Date().getFullYear()} Soneya Delivery</span><span>Conçu à Conakry par <strong>Guinée Hub Technologie</strong></span></footer>
    </div>
  );
};
